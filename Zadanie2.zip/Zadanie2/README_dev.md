W tym zadaniu należało jedynie uruchomić kontenery poleceniem:
docker compose -f docker-compose.dev.yml up -d