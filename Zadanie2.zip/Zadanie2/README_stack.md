W tym zadaniu należało uruchomić usługi w klastrze Swarm, do tego zostały użyte polecenia:
docker swarm init
docker stack deploy --compose-file docker-swarm.yml z2
