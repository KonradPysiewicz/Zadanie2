W tym zadaniu należało zbudować poszczególne obrazy oraz wystawić je na swojego dockerhub.
Polecenia do budowy obrazów:
docker build -t kpysiewicz/z2:client
docker build -t kpysiewicz/z2:nginx
docker build -t kpysiewicz/z2:server
docker build -t kpysiewicz/z2:worker

Polecenia do wystawienia obrazów:
docker push kpysiewicz/z2:client
docker push kpysiewicz/z2:nginx
docker push kpysiewicz/z2:server
docker push kpysiewicz/z2:worker

Do utworzenia kontenerów produkcyjnych zostało użyte polecenie:
docker compose -f docker-compose.yml up -d